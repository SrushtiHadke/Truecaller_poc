function logout() {
    alert("Logged out successfully");
    // window.location.href = "login.html";
}
